# Ćwiczenia – SQL Server Express w aplikacjach WWW (Node.js + Express + mssql)

## 1) Utwórz bazę i tabelę
Uruchom skrypt **init_demo_db.sql** na swoim SQL Server (Express lub Developer).

### Opcja A – `sqlcmd` (Windows PowerShell)
```powershell
# lokalny SQLEXPRESS (Windows uwierzytelnianie)
sqlcmd -S .\SQLEXPRESS -E -i init_demo_db.sql

# lub z logowaniem SQL
sqlcmd -S .\SQLEXPRESS -U sa -P "<haslo>" -i init_demo_db.sql
```

### Opcja B – VS Code (rozszerzenie "SQL Server (mssql)")
1. Połącz się z instancją.
2. Otwórz `init_demo_db.sql` i uruchom (Run Query).

## 2) Uruchom aplikację Node
```powershell
npm install
# skopiuj .env.example -> .env i dostosuj połączenie
copy .env.example .env
npm run dev
# http://localhost:3000/
```

### Zmienne środowiskowe (`.env`)
```env
SQL_SERVER=localhost\SQLEXPRESS
SQL_DATABASE=DemoDB
SQL_USER=
SQL_PASSWORD=
SQL_ENCRYPT=false
SQL_TRUST_SERVER_CERTIFICATE=true
SQL_PORT=1433
PORT=3000
```

> Dla Windows Authentication pozostaw `SQL_USER`/`SQL_PASSWORD` puste i uruchamiaj Node z konta, które ma dostęp do instancji. Alternatywnie podaj użytkownika SQL (np. `sa`).

## 3) Testuj endpointy
- `GET /` → `Serwer działa (Node + SQL Server)`  
- `GET /users` → JSON z rekordami z `dbo.Users`
- `GET /addUser?name=Test&email=test@example.com` → dodanie użytkownika (używa parametrów – bez SQL injection)

Przykład:
```
http://localhost:3000/addUser?name=Marcin&email=marcin@example.com
http://localhost:3000/users
```

## 4) Uwaga nt. zabezpieczeń
Endpoint dodający używa **parametryzowanych zapytań** (`@name`, `@email`).  
W prawdziwej aplikacji dodaj walidację i zmień metodę na `POST`.
