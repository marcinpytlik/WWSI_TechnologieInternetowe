import express from 'express';
import morgan from 'morgan';
import sql from 'mssql';
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.use(morgan('dev'));

const cfg = {
  server: process.env.SQL_SERVER || 'localhost\\SQLEXPRESS',
  database: process.env.SQL_DATABASE || 'DemoDB',
  user: process.env.SQL_USER || undefined,
  password: process.env.SQL_PASSWORD || undefined,
  port: process.env.SQL_PORT ? parseInt(process.env.SQL_PORT) : 1433,
  options: {
    encrypt: String(process.env.SQL_ENCRYPT || 'false').toLowerCase() === 'true',
    trustServerCertificate: String(process.env.SQL_TRUST_SERVER_CERTIFICATE || 'true').toLowerCase() === 'true',
    enableArithAbort: true
  },
  pool: { max: 10, min: 0, idleTimeoutMillis: 30000 }
};

let pool;
async function getPool() {
  if (pool && pool.connected) return pool;
  pool = await sql.connect(cfg);
  return pool;
}

// Root
app.get('/', (req, res) => {
  res.send('Serwer działa (Node + SQL Server)');
});

// GET /users -> JSON z rekordami z tabeli Users
app.get('/users', async (req, res) => {
  try {
    const p = await getPool();
    const result = await p.request().query('SELECT id, name, email, created_at FROM dbo.Users ORDER BY id DESC');
    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'DB error', detail: err.message });
  }
});

// GET /addUser?name=Test&email=test@example.com -> insert do Users
app.get('/addUser', async (req, res) => {
  const name = (req.query.name || '').toString().trim();
  const email = (req.query.email || '').toString().trim();
  if (!name || !email) return res.status(400).json({ message: 'Missing name/email' });

  try {
    const p = await getPool();
    const request = p.request();
    request.input('name', sql.NVarChar(100), name);
    request.input('email', sql.NVarChar(255), email);
    const result = await request.query(`
      INSERT INTO dbo.Users (name, email) VALUES (@name, @email);
      SELECT SCOPE_IDENTITY() AS id;
    `);
    const id = result.recordset && result.recordset[0]?.id;
    res.status(201).json({ id, name, email });
  } catch (err) {
    console.error(err);
    // np. naruszenie unikalności e-maila
    res.status(500).json({ message: 'DB error', detail: err.message });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server listening on http://localhost:${port}`);
});
