-- init_demo_db.sql
-- Tworzy bazę DemoDB oraz tabelę Users z prostymi danymi przykładowymi.

IF DB_ID(N'DemoDB') IS NULL
BEGIN
  PRINT 'Tworzenie bazy DemoDB...';
  CREATE DATABASE DemoDB;
END
GO

USE DemoDB;
GO

IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Users (
    id INT IDENTITY(1,1) CONSTRAINT PK_Users PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    email NVARCHAR(255) NOT NULL UNIQUE,
    created_at DATETIME2(0) NOT NULL CONSTRAINT DF_Users_CreatedAt DEFAULT (SYSUTCDATETIME())
  );
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Users)
BEGIN
  INSERT INTO dbo.Users(name, email) VALUES
    (N'Ala', N'ala@example.com'),
    (N'Jan', N'jan@example.com');
END
GO
