# Ćwiczenia – JavaScript zaawansowane

## Wymagania z zadania
- Pobieranie danych z publicznego API (`https://jsonplaceholder.typicode.com/users`) przy pomocy `fetch`.
- Wyświetlanie listy użytkowników w **tabeli**.
- Zapisywanie ostatniego wyszukiwania w **localStorage** i **automatyczne odczytanie** po odświeżeniu.

## Pliki
- `index.html` – struktura strony i tabela wyników.
- `css/styles.css` – lekki styl.
- `js/app.js` – logika (fetch, filtr, localStorage).

## Jak użyć
1. Otwórz `index.html` w przeglądarce.
2. Wpisz frazę w polu **Szukaj** – wyniki filtrują się w locie, a fraza jest zapisywana w `localStorage` (klucz: `lastQuery`).
3. Kliknij **Odśwież** aby ponownie pobrać dane z API.

> Uwaga: API JSONPlaceholder nie wymaga klucza i zwraca przykładowe dane do testów front-endu.
