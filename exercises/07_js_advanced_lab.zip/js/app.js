
const API = 'https://jsonplaceholder.typicode.com/users';
const KEY = 'lastQuery';

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const state = {
  raw: [],   // pełne dane z API
  view: []   // przefiltrowane w pamięci
};

async function fetchUsers() {
  setStatus('Ładowanie danych...');
  try {
    const res = await fetch(API, { cache: 'no-store' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    state.raw = Array.isArray(data) ? data : [];
    setStatus('Załadowano: ' + state.raw.length + ' użytkowników.');
  } catch (e) {
    console.error(e);
    setStatus('Błąd pobierania danych. Spróbuj ponownie.');
  }
}

function renderTable(list) {
  const tbody = $('#users tbody');
  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="6" class="muted">Brak wyników</td></tr>';
    return;
  }
  const rows = list.map(u => `
    <tr>
      <td>${escape(u.name)}</td>
      <td><a href="mailto:${escape(u.email)}">${escape(u.email)}</a></td>
      <td>${escape(u.phone)}</td>
      <td>${escape(u.company?.name || '')}</td>
      <td>${escape(u.address?.city || '')}</td>
      <td><a href="http://${escape(u.website)}" target="_blank" rel="noopener">${escape(u.website)}</a></td>
    </tr>
  `);
  tbody.innerHTML = rows.join('');
}

function filterList(q = '') {
  const term = q.trim().toLowerCase();
  if (!term) return state.raw.slice();
  return state.raw.filter(u => {
    return [u.name, u.email, u.phone, u.website, u.company?.name, u.address?.city]
      .filter(Boolean)
      .some(v => String(v).toLowerCase().includes(term));
  });
}

function setStatus(msg) {
  $('#status').textContent = msg || '';
}

function escape(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

async function init() {
  // Przywróć ostatnie wyszukiwanie
  const last = localStorage.getItem(KEY) || '';
  $('#search').value = last;

  await fetchUsers();
  state.view = filterList(last);
  renderTable(state.view);

  // Zdarzenia
  $('#search').addEventListener('input', (e) => {
    const q = e.target.value;
    localStorage.setItem(KEY, q);
    state.view = filterList(q);
    renderTable(state.view);
  });

  $('#reload').addEventListener('click', async () => {
    await fetchUsers();
    // Po odświeżeniu danych zachowujemy filtr z inputa
    const q = $('#search').value;
    state.view = filterList(q);
    renderTable(state.view);
  });
}

document.addEventListener('DOMContentLoaded', init);
