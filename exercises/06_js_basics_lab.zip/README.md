# Ćwiczenia – JavaScript podstawy

W zadaniu znajdują się trzy funkcje:
1. Po kliknięciu przycisku wyświetlany jest alert „Witaj w kursie!”.
2. Licznik zwiększa wartość przy każdym kliknięciu.
3. Nagłówek zmienia kolor po kliknięciu.

Pliki:
- `index.html` – struktura strony.
- `css/styles.css` – prosty wygląd.
- `js/script.js` – logika JavaScript.

Otwórz `index.html` w przeglądarce i przetestuj działanie.
