
// 1. Alert po kliknięciu przycisku
document.getElementById("alert-btn").addEventListener("click", () => {
  alert("Witaj w kursie!");
});

// 2. Licznik kliknięć
let counter = 0;
document.getElementById("counter-btn").addEventListener("click", () => {
  counter++;
  document.getElementById("counter-value").textContent = counter;
});

// 3. Zmiana koloru nagłówka po kliknięciu
document.getElementById("page-title").addEventListener("click", () => {
  document.getElementById("page-title").style.color = "#e53935";
});
