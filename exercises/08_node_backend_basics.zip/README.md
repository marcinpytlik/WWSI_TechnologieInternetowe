# Ćwiczenia – Backend z Node.js (Express)

## Wymagania z zadania
- `/` zwraca „Serwer działa”.
- `/time` zwraca bieżącą datę i godzinę (ISO + lokalnie).
- `/hello?name=Marcin` zwraca `Hello, Marcin` (gdy brak parametru – `Hello, World`).

## Start
```bash
npm install
npm run dev
# lub: npm start
# http://localhost:3000/
```
Możesz zmienić port przez zmienną środowiskową:
```bash
PORT=4000 npm run dev
```

## Przykłady
- `GET /` → `Serwer działa`
- `GET /time` → `{ "iso": "...", "locale": "..." }`
- `GET /hello?name=Marcin` → `Hello, Marcin`
