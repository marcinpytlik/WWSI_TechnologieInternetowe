import express from 'express';
import morgan from 'morgan';

const app = express();
app.use(morgan('dev'));

// GET / -> "Serwer działa"
app.get('/', (req, res) => {
  res.send('Serwer działa');
});

// GET /time -> bieżąca data i godzina w ISO
app.get('/time', (req, res) => {
  const now = new Date();
  res.json({
    iso: now.toISOString(),
    locale: now.toLocaleString()
  });
});

// GET /hello?name=Marcin -> "Hello, Marcin"
app.get('/hello', (req, res) => {
  const name = (req.query.name || 'World').toString();
  res.send(`Hello, ${name}`);
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Express server listening on http://localhost:${port}`);
});
