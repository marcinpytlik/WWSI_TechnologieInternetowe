-- init_project_db.sql
-- Tworzy bazę ProjectDB i tabelę uczestników (Participants).

IF DB_ID(N'ProjectDB') IS NULL
BEGIN
  CREATE DATABASE ProjectDB;
END
GO

USE ProjectDB;
GO

IF OBJECT_ID(N'dbo.Participants', N'U') IS NULL
BEGIN
  CREATE TABLE dbo.Participants (
    id INT IDENTITY(1,1) CONSTRAINT PK_Participants PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    email NVARCHAR(255) NOT NULL UNIQUE,
    created_at DATETIME2(0) NOT NULL CONSTRAINT DF_Participants_Created DEFAULT (SYSUTCDATETIME())
  );
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Participants)
BEGIN
  INSERT INTO dbo.Participants(name, email) VALUES
    (N'Ala Kowalska', N'ala@example.com'),
    (N'Jan Nowak', N'jan@example.com');
END
GO
