import express from 'express';
import morgan from 'morgan';
import path from 'path';
import { fileURLToPath } from 'url';
import sql from 'mssql';
import dotenv from 'dotenv';
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// --- SQL Server pool ---
const cfg = {
  server: process.env.SQL_SERVER || 'localhost\\SQLEXPRESS',
  database: process.env.SQL_DATABASE || 'ProjectDB',
  user: process.env.SQL_USER || undefined,
  password: process.env.SQL_PASSWORD || undefined,
  port: process.env.SQL_PORT ? parseInt(process.env.SQL_PORT) : 1433,
  options: {
    encrypt: String(process.env.SQL_ENCRYPT || 'false').toLowerCase() === 'true',
    trustServerCertificate: String(process.env.SQL_TRUST_SERVER_CERTIFICATE || 'true').toLowerCase() === 'true',
    enableArithAbort: true
  },
  pool: { max: 10, min: 0, idleTimeoutMillis: 30000 }
};

let pool;
async function getPool() {
  if (pool && pool.connected) return pool;
  pool = await sql.connect(cfg);
  return pool;
}

// --- API ---
// Health
app.get('/api/health', (req, res) => res.json({ ok: true }));

// List participants
app.get('/api/participants', async (req, res) => {
  try {
    const p = await getPool();
    const rs = await p.request().query(`
      SELECT id, name, email, created_at
      FROM dbo.Participants
      ORDER BY id DESC
    `);
    res.json(rs.recordset);
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: 'DB error', detail: e.message });
  }
});

// Add participant
app.post('/api/participants', async (req, res) => {
  const name = (req.body.name || '').toString().trim();
  const email = (req.body.email || '').toString().trim();
  if (!name || !email) return res.status(400).json({ message: 'Missing name or email' });
  try {
    const p = await getPool();
    const rq = p.request();
    rq.input('name', sql.NVarChar(100), name);
    rq.input('email', sql.NVarChar(255), email);
    const rs = await rq.query(`
      INSERT INTO dbo.Participants(name, email) VALUES(@name, @email);
      SELECT SCOPE_IDENTITY() AS id;
    `);
    const id = rs.recordset?.[0]?.id;
    res.status(201).json({ id, name, email });
  } catch (e) {
    // handle unique email violation
    const msg = e.message || '';
    const conflict = /unique|UNIQUE|UQ|duplicate/i.test(msg);
    console.error(e);
    res.status(conflict ? 409 : 500).json({ message: conflict ? 'Email already exists' : 'DB error', detail: msg });
  }
});

// Delete participant
app.delete('/api/participants/:id', async (req, res) => {
  const id = parseInt(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).json({ message: 'Invalid id' });
  try {
    const p = await getPool();
    const rq = p.request();
    rq.input('id', sql.Int, id);
    const rs = await rq.query('DELETE FROM dbo.Participants WHERE id = @id; SELECT @@ROWCOUNT AS rows;');
    const rows = rs.recordset?.[0]?.rows || 0;
    if (!rows) return res.status(404).json({ message: 'Not found' });
    res.json({ deleted: id });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: 'DB error', detail: e.message });
  }
});

// Fallback: index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Final Project running on http://localhost:${port}`);
});
