# Ćwiczenie – Projekt końcowy (Full‑stack mini‑app)
**Frontend:** HTML + CSS (RWD) • **JS:** walidacja/akcje • **Backend:** Node.js + Express • **DB:** SQL Server Express

Domyślny wariant: **„Formularz rejestracyjny z listą uczestników”** (łatwo przerobisz na mini‑blog albo ToDo).

## 1) Baza danych
Uruchom skrypt `init_project_db.sql` na swojej instancji SQL Server (Express/Developer).

### `sqlcmd` (Windows)
```powershell
sqlcmd -S .\SQLEXPRESS -E -i init_project_db.sql
# lub logowanie SQL:
# sqlcmd -S .\SQLEXPRESS -U sa -P "haslo" -i init_project_db.sql
```

### VS Code – rozszerzenie "SQL Server (mssql)"
Połącz się, otwórz `init_project_db.sql` i uruchom (Run Query).

## 2) Aplikacja Node
```powershell
npm install
copy .env.example .env
npm run dev
# http://localhost:3000
```

### `.env`
```env
SQL_SERVER=localhost\SQLEXPRESS
SQL_DATABASE=ProjectDB
SQL_USER=
SQL_PASSWORD=
SQL_ENCRYPT=false
SQL_TRUST_SERVER_CERTIFICATE=true
SQL_PORT=1433
PORT=3000
```

## 3) Frontend (RWD + JS)
- Formularz z walidacją (JS + atrybuty HTML).
- Dynamiczna lista uczestników (fetch `/api/participants`).
- Akcje dodawania i usuwania (POST/DELETE).

## 4) API (Express)
- `GET /api/participants` – lista `{ id, name, email, created_at }` (desc).
- `POST /api/participants` – dodanie (JSON body: `{ name, email }`).  
  Zwraca `201` lub `409` gdy email duplikuje.
- `DELETE /api/participants/:id` – usunięcie.

> Endpoints są osobno od statyków – single‑page index w `public/`.

## 5) Jak przerobić na inne warianty
- **Mini‑blog:** tabela `Posts(id, title, body, created_at)`, endpointy `/api/posts`, UI: formularz + lista.
- **ToDo:** tabela `Tasks(id, title, is_done bit, created_at)`, endpointy `GET/POST/PATCH/DELETE`, UI: checkbox + usuwanie.
- **Rejestracja uczestników (domyślnie)** – gotowe w paczce.

## 6) Bezpieczeństwo (skrót)
- Parametryzowane zapytania w `mssql` (`@name`, `@email`).
- Walidacja po stronie klienta i prosty handling błędów (409 dla duplikatu e‑maila).
- W realnym projekcie dodaj: POST zamiast GET dla mutacji, rate‑limit, autoryzację, obsługę migracji (np. Flyway).

Powodzenia! 💪
