const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function showError(name, msg) {
  const el = document.querySelector(`.error[data-for="${name}"]`);
  if (el) el.textContent = msg || '';
}

function validateForm(data) {
  let ok = true;
  showError('name', '');
  showError('email', '');
  if (!data.name || data.name.trim().length < 2) {
    showError('name', 'Podaj co najmniej 2 znaki.');
    ok = false;
  }
  if (!emailRe.test(data.email || '')) {
    showError('email', 'Podaj poprawny e-mail.');
    ok = false;
  }
  return ok;
}

async function fetchList() {
  $('#rows').innerHTML = `<tr><td colspan="5" class="muted">Ładowanie...</td></tr>`;
  const res = await fetch('/api/participants');
  const list = await res.json();
  renderList(list);
}

function renderList(list) {
  const q = ($('#filter').value || '').toLowerCase();
  const rows = list
    .filter(x => !q || [x.name, x.email].join(' ').toLowerCase().includes(q))
    .map(x => `
      <tr data-id="${x.id}">
        <td>${x.id}</td>
        <td>${escapeHtml(x.name)}</td>
        <td><a href="mailto:${escapeHtml(x.email)}">${escapeHtml(x.email)}</a></td>
        <td>${new Date(x.created_at).toLocaleString()}</td>
        <td><button class="btn danger" data-action="del">Usuń</button></td>
      </tr>
    `);
  $('#rows').innerHTML = rows.join('') || `<tr><td colspan="5" class="muted">Brak danych</td></tr>`;
}

function escapeHtml(s) {
  return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

async function addParticipant(data) {
  const res = await fetch('/api/participants', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  if (res.status === 409) {
    $('#form-status').textContent = 'E-mail już istnieje.';
    return;
  }
  if (!res.ok) {
    $('#form-status').textContent = 'Błąd zapisu.';
    return;
  }
  $('#form-status').textContent = 'Dodano.';
  $('#register-form').reset();
  await fetchList();
}

async function deleteParticipant(id) {
  const res = await fetch(`/api/participants/${id}`, { method: 'DELETE' });
  if (res.ok) {
    await fetchList();
  }
}

function wireUI() {
  // submit form
  $('#register-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = {
      name: $('#name').value.trim(),
      email: $('#email').value.trim(),
    };
    if (!validateForm(data)) return;
    await addParticipant(data);
  });

  // filter input
  $('#filter').addEventListener('input', () => fetchList());

  // toolbar reload
  $('#reload').addEventListener('click', () => fetchList());

  // delete buttons (event delegation)
  $('#rows').addEventListener('click', async (e) => {
    const btn = e.target.closest('button[data-action="del"]');
    if (!btn) return;
    const tr = btn.closest('tr[data-id]');
    const id = tr ? parseInt(tr.dataset.id) : null;
    if (id && confirm('Usunąć uczestnika #' + id + '?')) {
      await deleteParticipant(id);
    }
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  wireUI();
  await fetchList();
});
