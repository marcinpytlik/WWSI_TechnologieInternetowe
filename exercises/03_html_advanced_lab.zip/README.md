# Ćwiczenia – HTML zaawansowane elementy

W tym zadaniu zbudowano:
- **Formularz rejestracyjny** z polami: imię, e‑mail, hasło oraz checkbox zgody + przycisk **Wyślij**.
- Osadzono **wideo** poprzez `<video>` z atrybutem `controls` i `poster`.
- Sekcje oznaczono semantycznie: `<header>`, `<nav>`, `<article>`, `<footer>`.

## Pliki
- `index.html` – dokument HTML z semantyką, formularzem i wideo.
- `css/styles.css` – prosty, czytelny styl.
- `media/sample.mp4` – placeholder (podmień na swój film).
- `media/poster.jpg` – placeholder plakatu (podmień na grafikę).

## Szybki podgląd
Otwórz `index.html` w przeglądarce. Formularz ma walidację HTML5 (wymagane pola, email, min. długość hasła, zgoda).

> Uwaga: Do działania materiału wideo wstaw własny plik zamiast placeholdera `media/sample.mp4`.
